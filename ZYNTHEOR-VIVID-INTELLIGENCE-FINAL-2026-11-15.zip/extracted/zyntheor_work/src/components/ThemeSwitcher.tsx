import React from 'react';
import { useTheme, ThemeMode } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';
import { Sun, Moon, Laptop, Palette, Sparkles, Check, RotateCcw, ShieldCheck, ShieldAlert } from 'lucide-react';

export const ThemeSwitcher: React.FC = () => {
  const {
    theme,
    resolvedTheme,
    setTheme,
    customAccent,
    setCustomAccent,
    accentIntensity,
    setAccentIntensity,
    resetThemeDefaults
  } = useTheme();

  const { lang } = useLanguage();

  const themeOptions: Array<{
    id: ThemeMode;
    labelTh: string;
    labelEn: string;
    subTh: string;
    subEn: string;
    icon: React.ReactNode;
    bgPreview: string;
    borderPreview: string;
    accentPreview: string;
  }> = [
    {
      id: 'midnight-navy',
      labelTh: 'Midnight Navy (เนวี่ราตรี Batch 25)',
      labelEn: 'Midnight Navy (Flagship)',
      subTh: 'Deep Midnight Navy & Electric Cyan',
      subEn: 'Deep Midnight Navy & Electric Cyan',
      icon: <Palette className="w-4 h-4 text-[#00F0FF]" />,
      bgPreview: '#070B19',
      borderPreview: '#1E294A',
      accentPreview: '#00F0FF'
    },
    {
      id: 'light',
      labelTh: 'High-Contrast Light (สว่างคมชัด)',
      labelEn: 'High-Contrast Light',
      subTh: 'Clean · Crisp · Neon Blue',
      subEn: 'Clean · Crisp · Neon Blue',
      icon: <Sun className="w-4 h-4 text-[#FF5E3A]" />,
      bgPreview: '#F3F6FC',
      borderPreview: '#CBD5EA',
      accentPreview: '#2563EB'
    },
    {
      id: 'dark',
      labelTh: 'Dark Mode (มืดสนิท)',
      labelEn: 'Dark Mode',
      subTh: 'Midnight Navy & Neon Blue',
      subEn: 'Midnight Navy & Neon Blue',
      icon: <Moon className="w-4 h-4 text-[#2563EB]" />,
      bgPreview: '#070B19',
      borderPreview: '#1E294A',
      accentPreview: '#00F0FF'
    },
    {
      id: 'vivid-cyan',
      labelTh: 'Electric Cyan (ไซแอนนีออน)',
      labelEn: 'Electric Cyan',
      subTh: 'Electric Cyan & Luminous Lime',
      subEn: 'Electric Cyan & Luminous Lime',
      icon: <Sparkles className="w-4 h-4 text-[#00F0FF]" />,
      bgPreview: '#070B19',
      borderPreview: '#00F0FF4D',
      accentPreview: '#00F0FF'
    },
    {
      id: 'royal-purple',
      labelTh: 'Brilliant Violet (ม่วงไวโอเลต)',
      labelEn: 'Brilliant Violet',
      subTh: 'Brilliant Violet & Vivid Magenta',
      subEn: 'Brilliant Violet & Vivid Magenta',
      icon: <Sparkles className="w-4 h-4 text-[#FF007F]" />,
      bgPreview: '#09071A',
      borderPreview: '#7B2CBF73',
      accentPreview: '#7B2CBF'
    },
    {
      id: 'emerald-amber',
      labelTh: 'Aurora Classic (ออโรร่า)',
      labelEn: 'Aurora Classic',
      subTh: 'Midnight Surface & Coral',
      subEn: 'Midnight Surface & Coral',
      icon: <Sparkles className="w-4 h-4 text-[#CCFF00]" />,
      bgPreview: '#0D1326',
      borderPreview: '#1E294A',
      accentPreview: '#CCFF00'
    },
    {
      id: 'system',
      labelTh: 'System Default (ตามระบบปฏิบัติการ)',
      labelEn: 'System Default',
      subTh: 'Follows OS Dark/Light',
      subEn: 'Follows OS Dark/Light',
      icon: <Laptop className="w-4 h-4 text-slate-400" />,
      bgPreview: 'linear-gradient(135deg, #F3F6FC 50%, #070B19 50%)',
      borderPreview: '#94A3B8',
      accentPreview: '#2563EB'
    }
  ];

  const presetAccents = [
    { label: 'Electric Cyan', hex: '#00F0FF' },
    { label: 'Neon Blue', hex: '#2563EB' },
    { label: 'Brilliant Violet', hex: '#7B2CBF' },
    { label: 'Vivid Magenta', hex: '#FF007F' },
    { label: 'Coral Orange', hex: '#FF5E3A' },
    { label: 'Luminous Lime', hex: '#CCFF00' }
  ];

  return (
    <div className="space-y-6">
      {/* Theme Presets Grid */}
      <div>
        <div className="text-xs font-bold text-[var(--app-text-primary)] mb-3 flex items-center justify-between">
          <span>{lang === 'th' ? 'เลือกชุดสีและธีมหลัก (Theme Presets)' : 'Select Primary Theme Preset'}</span>
          <span className="text-[11px] font-mono font-medium text-[var(--app-text-secondary)]">
            Active: <span className="font-bold text-[var(--app-accent)] uppercase">{resolvedTheme}</span>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {themeOptions.map((opt) => {
            const isSelected = theme === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => setTheme(opt.id)}
                className={`p-3.5 rounded-2xl border text-left transition-all relative cursor-pointer ${
                  isSelected
                    ? 'border-[var(--app-accent)] shadow-md ring-2 ring-[var(--app-accent)]/20 bg-[var(--app-surface)]'
                    : 'border-[var(--app-card-border)] bg-[var(--app-surface)]/60 hover:bg-[var(--app-surface)]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800">
                      {opt.icon}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[var(--app-text-primary)]">
                        {lang === 'th' ? opt.labelTh : opt.labelEn}
                      </div>
                      <div className="text-[10px] text-[var(--app-text-secondary)]">
                        {lang === 'th' ? opt.subTh : opt.subEn}
                      </div>
                    </div>
                  </div>

                  {isSelected && (
                    <span className="w-5 h-5 rounded-full bg-[var(--app-accent)] text-white flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </span>
                  )}
                </div>

                {/* Mini Preview Bar */}
                <div className="mt-3 flex items-center gap-1.5 pt-2 border-t border-[var(--app-card-border)]">
                  <div
                    className="w-4 h-4 rounded-md border"
                    style={{ background: opt.bgPreview, borderColor: opt.borderPreview }}
                    title="Background"
                  />
                  <div
                    className="w-4 h-4 rounded-md"
                    style={{ background: opt.accentPreview }}
                    title="Accent"
                  />
                  <span className="text-[9px] font-mono text-[var(--app-text-secondary)] ml-auto">
                    {opt.id}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Accent Color & Intensity */}
      <div className="p-4 rounded-2xl bg-[var(--app-surface)] border border-[var(--app-card-border)] space-y-4">
        <div>
          <label className="block text-xs font-bold text-[var(--app-text-primary)] mb-2">
            {lang === 'th' ? 'สีเน้นเฉพาะตัว (Custom Accent Color)' : 'Custom Accent Color'}
          </label>
          <div className="flex flex-wrap items-center gap-2">
            {presetAccents.map((pa) => {
              const isActive = (customAccent || '#397BFF').toLowerCase() === pa.hex.toLowerCase();
              return (
                <button
                  key={pa.hex}
                  onClick={() => setCustomAccent(pa.hex)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'border-slate-800 shadow-sm scale-105'
                      : 'border-slate-200/80 hover:scale-102'
                  }`}
                  style={{
                    backgroundColor: pa.hex + '18',
                    color: pa.hex
                  }}
                >
                  <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: pa.hex }} />
                  <span>{pa.label}</span>
                </button>
              );
            })}

            {/* Custom Hex Picker Input */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl border border-[var(--app-card-border)] bg-[var(--app-input-bg)]">
              <input
                type="color"
                value={customAccent || '#397BFF'}
                onChange={(e) => setCustomAccent(e.target.value)}
                className="w-5 h-5 rounded cursor-pointer border-0 p-0 bg-transparent"
                title="Pick custom color"
              />
              <input
                type="text"
                value={customAccent || '#397BFF'}
                onChange={(e) => setCustomAccent(e.target.value)}
                placeholder="#397BFF"
                className="w-20 text-[11px] font-mono bg-transparent text-[var(--app-text-primary)] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Accent Intensity Slider */}
        <div className="pt-2 border-t border-[var(--app-card-border)]">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="font-bold text-[var(--app-text-primary)]">
              {lang === 'th' ? 'ความเข้มของสี Accent (Accent Intensity)' : 'Accent Intensity'}
            </span>
            <span className="font-mono font-bold text-[var(--app-accent)]">
              {Math.round(accentIntensity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.6"
            max="1.4"
            step="0.05"
            value={accentIntensity}
            onChange={(e) => setAccentIntensity(parseFloat(e.target.value))}
            className="w-full accent-[var(--app-accent)] cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-[var(--app-text-secondary)] mt-0.5">
            <span>60% (Subtle)</span>
            <span>100% (Standard)</span>
            <span>140% (Vibrant Neon)</span>
          </div>
        </div>

        {/* Contrast & Accessibility Verification Card */}
        <div className="p-3.5 rounded-xl bg-[var(--app-bg)] border border-[var(--app-card-border)]">
          <div className="text-[11px] font-bold text-[var(--app-text-primary)] uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>{lang === 'th' ? 'การรักษามาตรฐานการเข้าถึงและสีความปลอดภัย' : 'Accessibility & Status Color Invariants'}</span>
            <span className="text-[10px] text-emerald-600 font-mono font-bold">AAA ACCESSIBLE</span>
          </div>
          <p className="text-[11px] text-[var(--app-text-secondary)] mb-3 leading-relaxed">
            {lang === 'th'
              ? 'การปรับแต่งสีธีมจะไม่กระทบสีสถานะความปลอดภัยที่สำคัญ เช่น VERIFIED (สีเขียวมรกต) หรือ BLOCKED (สีแดงกุหลาบ) เพื่อให้การตรวจสอบ Audit ชัดเจนเสมอ'
              : 'Theme customization preserves all critical security status colors (VERIFIED: Emerald, BLOCKED: Rose) for uncompromised audit visibility.'}
          </p>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 border border-emerald-500/30 font-bold font-mono">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>VERIFIED / TAMPER-FREE</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/10 text-rose-600 border border-rose-500/30 font-bold font-mono">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>BLOCKED / TAMPER DETECTED</span>
            </div>
            <button
              onClick={resetThemeDefaults}
              className="ml-auto text-[11px] text-[var(--app-text-secondary)] hover:text-[var(--app-text-primary)] flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{lang === 'th' ? 'คืนค่าเริ่มต้น' : 'Reset Defaults'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
