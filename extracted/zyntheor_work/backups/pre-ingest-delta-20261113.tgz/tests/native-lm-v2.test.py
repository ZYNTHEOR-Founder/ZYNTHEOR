# -*- coding: utf-8 -*-
"""Regression tests for the P0 contract fixes (v1) and the learned LM v2 (P1-P4)."""
import os
import re
import sys
import struct
import hashlib
import tempfile
import unittest
import subprocess
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from qplus_native.tokenizer import SovereignTokenizer
from qplus_native.lm_v2 import NativeLM, LMConfig, real_vocab_size, V2_CHECKPOINT_PATH
from qplus_native.corpus import build_corpus
from qplus_native.trainer import NativeTrainer
from qplus_native.engine import cross_entropy_loss_and_grad
from qplus_native.checkpoint import CheckpointManager


def small_model(seed=3):
    m = NativeLM(LMConfig(vocab=40, d_model=16, n_layers=2, n_heads=4, d_ffn=24, ctx=8), seed=seed)
    rng = np.random.default_rng(0)
    for k in m.p:  # make gradients non-trivial
        m.p[k] = m.p[k] * 20 if m.p[k].ndim == 2 else m.p[k] + rng.normal(0, 0.1, m.p[k].shape)
    return m


class V1AttentionAndResume(unittest.TestCase):
    def test_v1_gradients_match_finite_difference_for_every_tensor(self):
        t = NativeTrainer()
        x, tgt = 7, 5

        def loss():
            return cross_entropy_loss_and_grad(t.forward_token(x)[0], tgt)[0]
        t.optimizer.zero_grad()
        lg, c = t.forward_token(x)
        _, d = cross_entropy_loss_and_grad(lg, tgt)
        t.backward_token(d, c)
        for p in t.parameters:
            for idx in range(0, p.size, max(1, p.size // 8)):
                g, o, e = p.grad[idx], p.data[idx], 1e-2
                p.data[idx] = o + e
                a = loss()
                p.data[idx] = o - e
                b = loss()
                p.data[idx] = o
                n = (a - b) / (2 * e)
                self.assertLess(abs(g - n), 2e-3 + 2e-2 * abs(n), f"grad mismatch in tensor shape {p.shape}")

    def test_v1_init_is_reproducible_across_processes(self):
        code = ("import sys;sys.path.insert(0,%r);from qplus_native.trainer import NativeTrainer;"
                "import hashlib;t=NativeTrainer();print(hashlib.sha256(bytes(t.get_flat_parameters().__repr__(),'utf8')).hexdigest())" % ROOT)
        outs = {subprocess.check_output([sys.executable, "-I", "-c", code], env={"PYTHONHASHSEED": s}).decode() for s in ("1", "2", "3")}
        self.assertEqual(len(outs), 1, "init must not depend on PYTHONHASHSEED")

    def test_v1_trainer_resumes_exact_checkpoint_weights(self):
        path = CheckpointManager.get_paths()[0]
        t = NativeTrainer()
        info = t.load_from_checkpoint(path)
        with open(path, "rb") as f:
            f.read(17)
            ml = struct.unpack(">I", f.read(4))[0]
            f.read(ml)
            payload = f.read()
        flat = np.array(t.get_flat_parameters(), dtype="<f4")
        self.assertEqual(flat.tobytes(), payload)
        self.assertEqual(info["loaded_params"], 231168)

    def test_v1_load_rejects_wrong_shape_checkpoint(self):
        t = NativeTrainer(d_model=64, d_ffn=128)
        with self.assertRaisesRegex(RuntimeError, "FAIL_CLOSED"):
            t.load_from_checkpoint(CheckpointManager.get_paths()[0])


class LMv2Math(unittest.TestCase):
    def test_every_tensor_gradient_matches_finite_difference(self):
        m = small_model()
        rng = np.random.default_rng(1)
        tok, tgt = rng.integers(0, 40, (3, 8)), rng.integers(0, 40, (3, 8))
        lg, c = m.forward(tok, True)
        _, dl = m.ce_loss(lg, tgt)
        g = m.backward(dl, c)

        def L():
            return m.ce_loss(m.forward(tok)[0], tgt)[0]
        for k, w in m.p.items():
            flat, gf = w.reshape(-1), g[k].reshape(-1)
            for i in rng.choice(flat.size, min(8, flat.size), replace=False):
                o, e = flat[i], 1e-5
                flat[i] = o + e
                a = L()
                flat[i] = o - e
                b = L()
                flat[i] = o
                n = (a - b) / (2 * e)
                self.assertLess(abs(n - gf[i]) / max(abs(n) + abs(gf[i]), 1e-8), 1e-5, k)

    def test_causality_future_tokens_do_not_change_past_logits(self):
        m = small_model()
        a = np.array([[1, 2, 3, 4, 5, 6, 7, 8]])
        b = a.copy()
        b[0, 5:] = [9, 9, 9]
        la, lb = m.forward(a)[0], m.forward(b)[0]
        np.testing.assert_allclose(la[0, :5], lb[0, :5], atol=1e-12)
        self.assertGreater(np.abs(la[0, 5:] - lb[0, 5:]).max(), 1e-6)

    def test_training_reduces_loss_on_toy_sequence(self):
        from qplus_native.lm_v2 import AdamW
        m = NativeLM(LMConfig(vocab=20, d_model=16, n_layers=1, n_heads=2, d_ffn=32, ctx=8), seed=1)
        opt = AdamW(m, lr=5e-3)
        seq = np.tile(np.arange(8), 4)[None, :9]
        x, y = seq[:, :8], seq[:, 1:9]
        first = None
        for _ in range(150):
            lg, c = m.forward(x, True)
            l, dl = m.ce_loss(lg, y)
            first = first if first is not None else l
            opt.step(m, m.backward(dl, c))
        self.assertLess(l, first * 0.2)


class LMv2Checkpoint(unittest.TestCase):
    def setUp(self):
        self.tok = SovereignTokenizer()
        self.m = NativeLM(LMConfig(vocab=real_vocab_size(self.tok), d_model=32, n_layers=1, n_heads=2, d_ffn=64, ctx=16), seed=5)
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "m.pt")
        self.m.save(self.path, self.tok)

    def test_roundtrip_and_inspector_verify(self):
        m2, meta = NativeLM.load(self.path, self.tok)
        x = np.array([[1, 5, 9, 20, 40]])
        np.testing.assert_allclose(self.m.forward(x)[0], m2.forward(x)[0], atol=1e-4)
        info = CheckpointManager.inspect_checkpoint(self.path)
        self.assertEqual(info["status"], "ACTIVE_TENSORS_VERIFIED")
        self.assertEqual(info["payload_float32_count"], self.m.num_params())

    def test_corrupted_payload_fails_closed(self):
        with open(self.path, "rb") as fh:
            raw = bytearray(fh.read())
        raw[-10] ^= 0xFF
        with open(self.path, "wb") as fh:
            fh.write(bytes(raw))
        with self.assertRaisesRegex(RuntimeError, "FAIL_CLOSED"):
            NativeLM.load(self.path, self.tok)

    def test_tokenizer_mismatch_fails_closed(self):
        other = SovereignTokenizer()
        other.id_to_token[100] = "ALTERED"
        with self.assertRaisesRegex(RuntimeError, "tokenizer vocabulary differs"):
            NativeLM.load(self.path, other)

    def test_generation_never_emits_control_or_filler_ids(self):
        out = self.m.generate_ids([1, 20, 30], max_new_tokens=40, temperature=1.0, top_k=0, seed=1)
        self.assertTrue(all(4 <= t < self.m.cfg.vocab for t in out))


class CorpusGovernance(unittest.TestCase):
    def test_split_is_by_document_without_leakage_and_excludes_tenant_secrets(self):
        c = build_corpus()
        ids = {d["split"]: {x["id"] for x in c["docs"] if x["split"] == d["split"]} for d in c["docs"]}
        self.assertFalse(ids["train"] & ids["val"])
        hashes = [d["sha256"] for d in c["docs"]]
        self.assertEqual(len(hashes), len(set(hashes)), "duplicate documents present")
        for d in c["docs"]:
            self.assertIsNone(re.search(r"TenantA Secret \d+", d["text"]))
            self.assertFalse(d["id"].startswith("knowledge:") and "Synthetic" in d["text"][:80])
        reasons = {e["id"]: e["reason"] for e in c["excluded"]}
        self.assertEqual(reasons.get("qplus_native/model.py"), "secret_like_literal")


@unittest.skipUnless(os.path.exists(V2_CHECKPOINT_PATH), "v2 checkpoint not trained yet")
class TrainedV2(unittest.TestCase):
    def test_trained_checkpoint_verifies_and_records_validation(self):
        info = CheckpointManager.inspect_checkpoint(V2_CHECKPOINT_PATH)
        self.assertEqual(info["status"], "ACTIVE_TENSORS_VERIFIED")
        meta = info["metadata"]
        self.assertEqual(meta["storage_mode"], "LEARNED_WEIGHTS_TRAINED_V2")
        self.assertIn("validation_loss", meta)
        self.assertFalse(meta["parameter_audit"]["target_architecture_instantiated"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
